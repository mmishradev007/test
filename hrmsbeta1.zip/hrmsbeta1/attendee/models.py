from django.db import models
from common.models import Country,State,City,Department,Designation,Category,Religion,Bank
from hierarchy.models import Franchisee,Center,Batch,Device
ST = (
    (1, 'Active'),
    (0, 'In-Active'),
)
MS = (
    (1, 'Married'),
    (0, 'Un-Married'),
)
GN = (
    (1, 'Male'),
    (0, 'Female'),
)
class Employee(models.Model):
    class Meta:
        ordering = ('-id',)
    center = models.ForeignKey(Center, models.SET_NULL, blank=True, null=True)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    biometric_id = models.CharField(max_length=50,unique=True)
    dob = models.CharField(max_length=50)
    doj = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    mobile = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    address1 = models.CharField(max_length=50)
    address2 = models.CharField(max_length=50)
    address3 = models.CharField(max_length=50)
    district = models.CharField(max_length=50)
    pincode = models.CharField(max_length=50)
    pan_no = models.CharField(max_length=50)
    aadhar_no = models.CharField(max_length=50)
    bank_account_no = models.CharField(max_length=50)
    ifsc_code = models.CharField(max_length=50)
    bank_accountholder_name = models.CharField(max_length=50)
    bank_branch = models.CharField(max_length=50)
    profilepic = models.FileField(upload_to='documents/',blank=True)
    city = models.ForeignKey(City,models.SET_NULL,blank=True,null=True)
    state = models.ForeignKey(State, models.SET_NULL, blank=True, null=True)
    country = models.ForeignKey(Country, models.SET_NULL, blank=True, null=True)
    caste = models.ForeignKey(Category, models.SET_NULL, blank=True, null=True)
    gender = models.IntegerField(choices=GN, blank=True)
    marital_status = models.IntegerField(choices=MS, blank=True)
    department = models.ForeignKey(Department, models.SET_NULL, blank=True, null=True)
    designation = models.ForeignKey(Designation, models.SET_NULL, blank=True, null=True)
    religion = models.ForeignKey(Religion, models.SET_NULL, blank=True, null=True)
    bank = models.ForeignKey(Bank, models.SET_NULL, blank=True, null=True)
    createdon = models.DateTimeField(auto_now_add=True)
    status = models.IntegerField(choices=ST,blank=True)


    def __str__(self):
        return print(f'%s %s',self.first_name,self.last_name)

class Student(models.Model):
    class Meta:
        ordering = ('-id',)

    center =  models.ForeignKey(Center, models.SET_NULL, blank=True, null=True)
    batch = models.ForeignKey(Batch, models.SET_NULL, blank=True, null=True)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    gender = models.IntegerField(choices=GN, blank=True)
    dob = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    mobile = models.CharField(max_length=50)
    qualification = models.CharField(max_length=50)
    address1 = models.CharField(max_length=50)
    address2 = models.CharField(max_length=50)
    pincode = models.CharField(max_length=50)
    aadhar_no = models.CharField(max_length=50)
    profilepic = models.FileField(upload_to='documents/',blank=True)
    createdon = models.DateTimeField(auto_now_add=True)
    status = models.IntegerField(choices=ST, blank=True)
    city = models.ForeignKey(City, models.SET_NULL, blank=True, null=True)
    state = models.ForeignKey(State, models.SET_NULL, blank=True, null=True)
    country = models.ForeignKey(Country, models.SET_NULL, blank=True, null=True)

    def __str__(self):
        return print(f'%s %s',self.first_name,self.last_name)