from django.urls import path
from attendee import views
from .views import (
EmployeeListView,EmployeeCreate,EmployeeUpdate,EmployeeDelete,
StudentListView,StudentCreate,StudentUpdate,StudentDelete,
)

app_name = 'attendee'

urlpatterns = [
    path('employee/', EmployeeListView.as_view(), name='employee'),
    path('employee/add', EmployeeCreate.as_view(), name='employee_create'),
    path('employee/edit/<int:pk>', EmployeeUpdate.as_view(), name='employee_edit'),
    path('employee/delete/<int:pk>', EmployeeDelete.as_view(), name='employee_delete'),

    path('student/', StudentListView.as_view(), name='student'),
    path('student/add', StudentCreate.as_view(), name='student_create'),
    path('student/edit/<int:pk>', StudentUpdate.as_view(), name='student_edit'),
    path('student/delete/<int:pk>', StudentDelete.as_view(), name='student_delete'),
    path('export_student/', views.export_student, name='export_student'),
    path('export_employee/', views.export_employee, name='export_employee'),
]
