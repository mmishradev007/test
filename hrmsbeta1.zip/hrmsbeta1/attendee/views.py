from django.views.generic import View, FormView,ListView,CreateView,UpdateView,DeleteView
from .models import Employee,Student
from django.urls import reverse_lazy
from django.http import HttpResponse
from .resources import StudentResource,EmployeeResource
from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import (
    EmployeeForm,StudentForm
)

class EmployeeListView(LoginRequiredMixin,ListView):

    model = Employee
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_employee_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('employee', )
        except KeyError:
            a = None
        if a:
            employee_list = Employee.objects.filter(
                name__icontains=a,
            )
        else:
            employee_list = Employee.objects.filter()
        return employee_list

    def dispatch(self, *args, **kwargs):
        return super(EmployeeListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(EmployeeListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Employee'
        return context


class EmployeeCreate(LoginRequiredMixin,CreateView):
    form_class = EmployeeForm
    model = Employee
    success_url = reverse_lazy('attendee:employee')

    def get_context_data(self, **kwargs):
        context = super(EmployeeCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add Employee'
        return context

class EmployeeUpdate(LoginRequiredMixin,UpdateView):
    form_class = EmployeeForm
    model = Employee
    success_url = reverse_lazy('attendee:employee')

    def get_context_data(self, **kwargs):
        context = super(EmployeeUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update Employee'
        return context

class EmployeeDelete(LoginRequiredMixin,DeleteView):
    model = Employee

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('attendee:employee')



class StudentListView(LoginRequiredMixin,ListView):

    model = Student
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_student_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('student', )
        except KeyError:
            a = None
        if a:
            student_list = Student.objects.filter(
                name__icontains=a,
            )
        else:
            student_list = Student.objects.filter()
        return student_list

    def dispatch(self, *args, **kwargs):
        return super(StudentListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(StudentListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Student'
        return context


class StudentCreate(LoginRequiredMixin,CreateView):
    form_class = StudentForm
    model = Student
    success_url = reverse_lazy('attendee:student')

    def get_context_data(self, **kwargs):
        context = super(StudentCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add Student'
        return context

class StudentUpdate(LoginRequiredMixin,UpdateView):
    form_class = StudentForm
    model = Student
    success_url = reverse_lazy('attendee:student')

    def get_context_data(self, **kwargs):
        context = super(StudentUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update Student'
        return context

class StudentDelete(LoginRequiredMixin,DeleteView):
    model = Student

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('attendee:student')

def export_student(request):
    student_resource = StudentResource()
    dataset = student_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="students.csv"'
    return response

def export_employee(request):
    employee_resource = EmployeeResource()
    dataset = employee_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="employees.csv"'
    return response