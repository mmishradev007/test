from django import forms
from django.forms import TextInput,Select,FileInput
from .models  import Employee,Student
class UserCacheMixin:
    user_cache = None

class EmployeeForm(UserCacheMixin, forms.ModelForm):
    class Meta:
        model = Employee
        fields = ['center','first_name','last_name','biometric_id','dob','doj','phone','mobile','email','address1','address2','address3','district','pincode','pan_no','aadhar_no','bank_account_no','ifsc_code','bank_accountholder_name','bank_branch','profilepic','city','state','country','caste','gender','marital_status','department','designation','religion','bank','status']
        widgets = {
            'center': Select(attrs={'class':'form-control selectbox'}),
            'first_name': TextInput(attrs={'class':'form-control'}),
            'last_name': TextInput(attrs={'class': 'form-control'}),
            'biometric_id': TextInput(attrs={'class': 'form-control'}),
            'dob': TextInput(attrs={'class': 'form-control datepicker'}),
            'doj': TextInput(attrs={'class': 'form-control datepicker'}),
            'phone': TextInput(attrs={'class': 'form-control'}),
            'mobile': TextInput(attrs={'class': 'form-control'}),
            'email': TextInput(attrs={'class': 'form-control'}),
            'address1': TextInput(attrs={'class': 'form-control'}),
            'address2': TextInput(attrs={'class': 'form-control'}),
            'address3': TextInput(attrs={'class': 'form-control '}),
            'district':TextInput(attrs={'class': 'form-control '}),
            'pincode':TextInput(attrs={'class': 'form-control '}),
            'pan_no':TextInput(attrs={'class': 'form-control '}),
            'aadhar_no':TextInput(attrs={'class': 'form-control '}),
            'bank_account_no':TextInput(attrs={'class': 'form-control '}),
            'ifsc_code':TextInput(attrs={'class': 'form-control '}),
            'bank_accountholder_name':TextInput(attrs={'class': 'form-control '}),
            'bank_branch':TextInput(attrs={'class': 'form-control '}),
            'profilepic':FileInput(attrs={'class': 'form-control '}),
            'city':Select(attrs={'class': 'form-control selectbox'}),
            'state':Select(attrs={'class': 'form-control selectbox'}),
            'country':Select(attrs={'class': 'form-control selectbox'}),
            'caste':Select(attrs={'class': 'form-control selectbox'}),
            'gender':Select(attrs={'class': 'form-control selectbox'}),
            'marital_status':Select(attrs={'class': 'form-control selectbox'}),
            'department':Select(attrs={'class': 'form-control selectbox'}),
            'designation':Select(attrs={'class': 'form-control selectbox'}),
            'religion':Select(attrs={'class': 'form-control selectbox'}),
            'bank':Select(attrs={'class': 'form-control selectbox'}),
            'status': Select(attrs={'class': 'form-control selectbox'}),
        }

class StudentForm(UserCacheMixin, forms.ModelForm):
    class Meta:
        model = Student
        fields = ['center','batch','first_name','last_name','gender','dob','email','mobile','qualification','address1','address2','pincode','aadhar_no','profilepic','city','state','country','status']
        widgets = {
            'center': Select(attrs={'class': 'form-control selectbox'}),
            'batch': Select(attrs={'class': 'form-control selectbox'}),
            'first_name': TextInput(attrs={'class': 'form-control'}),
            'last_name': TextInput(attrs={'class': 'form-control'}),
            'gender': Select(attrs={'class': 'form-control selectbox'}),
            'dob': TextInput(attrs={'class': 'form-control datepicker'}),
            'email': TextInput(attrs={'class': 'form-control'}),
            'mobile': TextInput(attrs={'class': 'form-control'}),
            'qualification': TextInput(attrs={'class': 'form-control'}),
            'address1': TextInput(attrs={'class': 'form-control'}),
            'address2': TextInput(attrs={'class': 'form-control'}),
            'pincode': TextInput(attrs={'class': 'form-control'}),
            'aadhar_no': TextInput(attrs={'class': 'form-control'}),
            'profilepic': FileInput(attrs={'class': 'form-control'}),
            'city': Select(attrs={'class': 'form-control selectbox'}),
            'state': Select(attrs={'class': 'form-control selectbox'}),
            'country': Select(attrs={'class': 'form-control selectbox'}),
            'status': Select(attrs={'class': 'form-control selectbox'}),
        }