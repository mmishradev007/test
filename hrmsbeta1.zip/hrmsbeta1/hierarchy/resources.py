from import_export import resources
from .models import Franchisee,Center,Batch,Device

class FranchiseeResource(resources.ModelResource):
    class Meta:
        model = Franchisee

class CenterResource(resources.ModelResource):
    class Meta:
        model = Center

class BatchResource(resources.ModelResource):
    class Meta:
        model = Batch

class DeviceResource(resources.ModelResource):
    class Meta:
        model = Device