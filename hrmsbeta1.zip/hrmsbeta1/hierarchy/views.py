from django.views.generic import View, FormView,ListView,CreateView,UpdateView,DeleteView
from .models import Franchisee,Center,Batch,Device
from django.urls import reverse_lazy
from django.http import HttpResponse
from .resources import FranchiseeResource,CenterResource,BatchResource,DeviceResource

from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import (
    FranchiseeForm,CenterForm,BatchForm,DeviceForm
)

class FranchiseeListView(LoginRequiredMixin,ListView):

    model = Franchisee
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_franchisee_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('franchisee', )
        except KeyError:
            a = None
        if a:
            franchisee_list = Franchisee.objects.filter(
                name__icontains=a,
            )
        else:
            franchisee_list = Franchisee.objects.filter()
        return franchisee_list

    def dispatch(self, *args, **kwargs):
        return super(FranchiseeListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(FranchiseeListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Franchisee'
        return context


class FranchiseeCreate(LoginRequiredMixin,CreateView):
    form_class = FranchiseeForm
    model = Franchisee
    success_url = reverse_lazy('hierarchy:franchisee')

    def get_context_data(self, **kwargs):
        context = super(FranchiseeCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add Franchisee'
        return context


class FranchiseeUpdate(LoginRequiredMixin,UpdateView):
    form_class = FranchiseeForm

    model = Franchisee
    success_url = reverse_lazy('hierarchy:franchisee')

    def get_context_data(self, **kwargs):
        context = super(FranchiseeUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS |Update Franchisee'
        return context


class FranchiseeDelete(LoginRequiredMixin,DeleteView):
    model = Franchisee

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('hierarchy:franchisee')



class CenterListView(LoginRequiredMixin,ListView):

    model = Center
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_center_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('center', )
        except KeyError:
            a = None
        if a:
            center_list = Center.objects.filter(
                name__icontains=a,
            )
        else:
            center_list = Center.objects.filter()
        return center_list

    def dispatch(self, *args, **kwargs):
        return super(CenterListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(CenterListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Center'
        return context



class CenterCreate(LoginRequiredMixin,CreateView):
    form_class = CenterForm
    model = Center
    success_url = reverse_lazy('hierarchy:center')

    def get_context_data(self, **kwargs):
        context = super(CenterCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add Center'
        return context


class CenterUpdate(LoginRequiredMixin,UpdateView):
    form_class = CenterForm
    model = Center
    success_url = reverse_lazy('hierarchy:center')

    def get_context_data(self, **kwargs):
        context = super(CenterUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update Center'
        return context


class CenterDelete(LoginRequiredMixin,DeleteView):
    model = Center

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('hierarchy:center')


class BatchListView(LoginRequiredMixin,ListView):

    model = Batch
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_batch_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('batch', )
        except KeyError:
            a = None
        if a:
            batch_list = Batch.objects.filter(
                name__icontains=a,
            )
        else:
            batch_list = Batch.objects.filter()
        return batch_list

    def dispatch(self, *args, **kwargs):
        return super(BatchListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(BatchListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Batch'
        return context



class BatchCreate(LoginRequiredMixin,CreateView):
    form_class = BatchForm
    model = Batch
    success_url = reverse_lazy('hierarchy:batch')

    def get_context_data(self, **kwargs):
        context = super(BatchCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add Batch'
        return context


class BatchUpdate(LoginRequiredMixin,UpdateView):
    form_class = BatchForm
    model = Batch
    success_url = reverse_lazy('hierarchy:batch')

    def get_context_data(self, **kwargs):
        context = super(FranchiseeListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update Batch'
        return context


class BatchDelete(LoginRequiredMixin,DeleteView):
    model = Batch

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('hierarchy:batch')


class DeviceListView(LoginRequiredMixin,ListView):

    model = Device
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_device_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('device', )
        except KeyError:
            a = None
        if a:
            device_list = Device.objects.filter(
                name__icontains=a,
            )
        else:
            device_list = Device.objects.filter()
        return device_list

    def dispatch(self, *args, **kwargs):
        return super(DeviceListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(DeviceListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Device'
        return context



class DeviceCreate(LoginRequiredMixin,CreateView):
    form_class = DeviceForm
    model = Device
    success_url = reverse_lazy('hierarchy:device')

    def get_context_data(self, **kwargs):
        context = super(DeviceCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add Device'
        return context


class DeviceUpdate(LoginRequiredMixin,UpdateView):
    form_class = DeviceForm
    model = Device
    success_url = reverse_lazy('hierarchy:device')

    def get_context_data(self, **kwargs):
        context = super(DeviceUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update Device'
        return context


class DeviceDelete(LoginRequiredMixin,DeleteView):
    model = Device

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('hierarchy:device')

def export_franchisee(request):
    franchisee_resource = FranchiseeResource()
    dataset = franchisee_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="franchisee.csv"'
    return response

def export_center(request):
    center_resource = CenterResource()
    dataset = center_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="center.csv"'
    return response

def export_batch(request):
    batch_resource = BatchResource()
    dataset = batch_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="batch.csv"'
    return response

def export_device(request):
    device_resource = DeviceResource()
    dataset = device_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="device.csv"'
    return response