from django.urls import path
from hierarchy import views
from .views import (
    FranchiseeListView,FranchiseeCreate,FranchiseeUpdate,FranchiseeDelete,
CenterListView,CenterCreate,CenterUpdate,CenterDelete,
BatchListView,BatchCreate,BatchUpdate,BatchDelete,
DeviceListView,DeviceCreate,DeviceUpdate,DeviceDelete,
)

app_name = 'hierarchy'

urlpatterns = [
    path('franchisee/', FranchiseeListView.as_view(), name='franchisee'),
    path('franchisee/add', FranchiseeCreate.as_view(), name='franchisee_create'),
    path('franchisee/edit/<int:pk>', FranchiseeUpdate.as_view(), name='franchisee_edit'),
    path('franchisee/delete/<int:pk>', FranchiseeDelete.as_view(), name='franchisee_delete'),

    path('center/', CenterListView.as_view(), name='center'),
    path('center/add', CenterCreate.as_view(), name='center_create'),
    path('center/edit/<int:pk>', CenterUpdate.as_view(), name='center_edit'),
    path('center/delete/<int:pk>', CenterDelete.as_view(), name='center_delete'),

    path('batch/', BatchListView.as_view(), name='batch'),
    path('batch/add', BatchCreate.as_view(), name='batch_create'),
    path('batch/edit/<int:pk>', BatchUpdate.as_view(), name='batch_edit'),
    path('batch/delete/<int:pk>', BatchDelete.as_view(), name='batch_delete'),

    path('device/', DeviceListView.as_view(), name='device'),
    path('device/add', DeviceCreate.as_view(), name='device_create'),
    path('device/edit/<int:pk>', DeviceUpdate.as_view(), name='device_edit'),
    path('device/delete/<int:pk>',DeviceDelete.as_view(), name='device_delete'),

    path('export_franchisee/', views.export_franchisee, name='export_franchisee'),
    path('export_center/', views.export_center, name='export_center'),
    path('export_batch/', views.export_batch, name='export_batch'),
    path('export_device/', views.export_device, name='export_device'),
]
