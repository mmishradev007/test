from django.db import models
from common.models import Country,State,City
ST = (
    (1, 'Active'),
    (0, 'In-Active'),
)
class Franchisee(models.Model):
    class Meta:
        ordering = ('-id',)
    name = models.CharField(max_length=50,unique=True)
    phone = models.CharField(max_length=20)
    mobile = models.CharField(max_length=20)
    primary_email = models.CharField(max_length=50, unique=True)
    secondary_email = models.CharField(max_length=50)
    website = models.CharField(max_length=50)
    logo = models.FileField(upload_to='documents/',blank=True)
    address1 = models.CharField(max_length=100)
    address2 = models.CharField(max_length=100)
    address3 = models.CharField(max_length=100)
    pincode = models.CharField(max_length=20)
    city = models.ForeignKey(City,models.SET_NULL,blank=True,null=True)
    state = models.ForeignKey(State,models.SET_NULL,blank=True,null=True)
    country = models.ForeignKey(Country,models.SET_NULL,blank=True,null=True)
    createdon = models.DateTimeField(auto_now_add=True)
    status = models.IntegerField(choices=ST,blank=True)

    def __str__(self):
        return self.name

class Center(models.Model):
    class Meta:
        ordering = ('-id',)
    name = models.CharField(max_length=50, unique=True)
    phone = models.CharField(max_length=20)
    mobile = models.CharField(max_length=20)
    primary_email = models.CharField(max_length=50, unique=True)
    secondary_email = models.CharField(max_length=50)
    website = models.CharField(max_length=50)
    address1 = models.CharField(max_length=100)
    address2 = models.CharField(max_length=100)
    address3 = models.CharField(max_length=100)
    pincode = models.CharField(max_length=20)
    franchisee = models.ForeignKey(Franchisee,models.SET_NULL,blank=True,null=True)
    city = models.ForeignKey(City,models.SET_NULL,blank=True,null=True)
    state = models.ForeignKey(State,models.SET_NULL,blank=True,null=True)
    country = models.ForeignKey(Country,models.SET_NULL,blank=True,null=True)
    createdon = models.DateTimeField(auto_now_add=True)
    status = models.IntegerField(choices=ST, blank=True)

    def __str__(self):
        return self.name

class Batch(models.Model):
    class Meta:
        ordering = ('-id',)
    center = models.ForeignKey(Center,models.SET_NULL,blank=True,null=True)
    name = models.CharField(max_length=100, unique=True)
    start_time = models.CharField(max_length=20)
    end_time = models.CharField(max_length=20)
    start_date = models.CharField(max_length=20)
    end_date = models.CharField(max_length=20)
    week_offs = models.CharField(max_length=20)
    status = models.IntegerField(choices=ST,blank=True)

    def __str__(self):
        return self.name

class Device(models.Model):
    class Meta:
        ordering = ('-id',)
    center = models.ForeignKey(Center,models.SET_NULL,blank=True,null=True)
    model_number = models.CharField(max_length=100)
    serial_number = models.CharField(max_length=100)
    status = models.IntegerField(choices=ST, blank=True)

    def __str__(self):
        return self.name