from django import forms
from django.forms import TextInput,Select,FileInput
from .models  import Franchisee,Center,Batch,Device
class UserCacheMixin:
    user_cache = None

class FranchiseeForm(UserCacheMixin, forms.ModelForm):
    class Meta:
        model = Franchisee
        fields = ['logo','name','phone','mobile','primary_email','secondary_email','website','address1','address2','address3','pincode','city','state','country','status']
        widgets = {
            'name': TextInput(attrs={'class':'form-control'}),
            'phone': TextInput(attrs={'class':'form-control'}),
            'mobile': TextInput(attrs={'class': 'form-control'}),
            'primary_email': TextInput(attrs={'class': 'form-control'}),
            'secondary_email': TextInput(attrs={'class': 'form-control'}),
            'website': TextInput(attrs={'class': 'form-control'}),
            'logo': FileInput(attrs={'class': 'form-control'}),
            'address1': TextInput(attrs={'class': 'form-control'}),
            'address2': TextInput(attrs={'class': 'form-control'}),
            'address3': TextInput(attrs={'class': 'form-control'}),
            'pincode': TextInput(attrs={'class': 'form-control'}),
            'city': Select(attrs={'class': 'form-control selectbox'}),
            'state': Select(attrs={'class': 'form-control selectbox'}),
            'country': Select(attrs={'class': 'form-control selectbox'}),
            'status': Select(attrs={'class': 'form-control selectbox'}),
        }

class CenterForm(UserCacheMixin, forms.ModelForm):
    class Meta:
        model = Center
        fields = ['name', 'franchisee','phone', 'mobile', 'primary_email', 'secondary_email', 'website', 'address1', 'address2',
                  'address3', 'pincode', 'city', 'state', 'country', 'status']
        widgets = {
            'name': TextInput(attrs={'class': 'form-control'}),
            'franchisee': Select(attrs={'class': 'form-control'}),
            'phone': TextInput(attrs={'class': 'form-control'}),
            'mobile': TextInput(attrs={'class': 'form-control'}),
            'primary_email': TextInput(attrs={'class': 'form-control'}),
            'secondary_email': TextInput(attrs={'class': 'form-control'}),
            'website': TextInput(attrs={'class': 'form-control'}),
            'address1': TextInput(attrs={'class': 'form-control'}),
            'address2': TextInput(attrs={'class': 'form-control'}),
            'address3': TextInput(attrs={'class': 'form-control'}),
            'pincode': TextInput(attrs={'class': 'form-control'}),
            'city': Select(attrs={'class': 'form-control selectbox'}),
            'state': Select(attrs={'class': 'form-control selectbox'}),
            'country': Select(attrs={'class': 'form-control selectbox'}),
            'status': Select(attrs={'class': 'form-control selectbox'}),
        }

class BatchForm(UserCacheMixin, forms.ModelForm):
    class Meta:
        model = Batch
        fields = ['center','name','start_time','end_time','start_date','end_date','week_offs','status']
        widgets = {
            'center': Select(attrs={'class': 'form-control selectbox'}),
            'name': TextInput(attrs={'class': 'form-control'}),
            'start_time': TextInput(attrs={'class': 'form-control'}),
            'end_time': TextInput(attrs={'class': 'form-control'}),
            'start_date': TextInput(attrs={'class': 'form-control datepicker'}),
            'end_date': TextInput(attrs={'class': 'form-control datepicker multiple'}),
            'week_offs': TextInput(attrs={'class': 'form-control'}),
            'status': Select(attrs={'class': 'form-control selectbox'}),
        }
class DeviceForm(UserCacheMixin, forms.ModelForm):
    class Meta:
        model = Device
        fields = ['center','model_number','serial_number','status']
        widgets = {
            'center': Select(attrs={'class': 'form-control selectbox'}),
            'model_number': TextInput(attrs={'class': 'form-control'}),
            'serial_number': TextInput(attrs={'class': 'form-control'}),
            'status': Select(attrs={'class': 'form-control selectbox'}),
        }