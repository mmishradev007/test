from django.views.generic import View, FormView,ListView,CreateView,UpdateView,DeleteView
from .models import Country,State,City,Religion,Bank,Category,Department,Designation
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse
from .resources import CountryResource,StateResource,CityResource,ReligionResource,CategoryResource,BankResource,DepartmentResource,DesignationResource
from .forms import (
    CountryForm,StateForm,CityForm,ReligionForm,BankForm,CategoryForm,DepartmentForm,DesignationForm
)

class CountryListView(LoginRequiredMixin,ListView):

    model = Country
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_book_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('country', )
        except KeyError:
            a = None
        if a:
            country_list = Country.objects.filter(
                name__icontains=a,
                #owner=self.request.user
            )
        else:
            country_list = Country.objects.filter()
        return country_list

    def get_context_data(self, **kwargs):
        context = super(CountryListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Country'
        return context

    def dispatch(self, *args, **kwargs):
        return super(CountryListView, self).dispatch(*args, **kwargs)


class CountryCreate(LoginRequiredMixin,CreateView):
    form_class = CountryForm
    model = Country
    success_url = reverse_lazy('common:country')
    def get_context_data(self, **kwargs):
        context = super(CountryCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add Country'
        return context

class CountryUpdate(LoginRequiredMixin,UpdateView):
    form_class = CountryForm
    model = Country
    success_url = reverse_lazy('common:country')
    def get_context_data(self, **kwargs):
        context = super(CountryUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update Country'
        return context

class CountryDelete(LoginRequiredMixin,DeleteView):
    model = Country

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('common:country')



class StateListView(LoginRequiredMixin,ListView):

    model = State
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_state_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('state', )
        except KeyError:
            a = None
        if a:
            state_list = State.objects.filter(
                name__icontains=a,
            )
        else:
            state_list = State.objects.filter()
        return state_list

    def dispatch(self, *args, **kwargs):
        return super(StateListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(StateListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | State'
        return context


class StateCreate(LoginRequiredMixin,CreateView):
    form_class = StateForm
    model = State
    success_url = reverse_lazy('common:state')

    def get_context_data(self, **kwargs):
        context = super(StateCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add State'
        return context

class StateUpdate(LoginRequiredMixin,UpdateView):
    form_class = StateForm
    model = State
    success_url = reverse_lazy('common:state')

    def get_context_data(self, **kwargs):
        context = super(StateUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update State'
        return context

class StateDelete(LoginRequiredMixin,DeleteView):
    model = State

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('common:state')


class CityListView(LoginRequiredMixin,ListView):

    model = City
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_city_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('city', )
        except KeyError:
            a = None
        if a:
            city_list = City.objects.filter(
                name__icontains=a,
                #owner=self.request.user
            )
        else:
            city_list = City.objects.filter()
        return city_list

    def dispatch(self, *args, **kwargs):
        return super(CityListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(CityListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | City'
        return context


class CityCreate(LoginRequiredMixin,CreateView):
    form_class = CityForm
    model = City
    success_url = reverse_lazy('common:city')

    def get_context_data(self, **kwargs):
        context = super(CityCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add City'
        return context

class CityUpdate(LoginRequiredMixin,UpdateView):
    form_class = CityForm
    model = City
    success_url = reverse_lazy('common:city')

    def get_context_data(self, **kwargs):
        context = super(CityUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update City'
        return context

class CityDelete(LoginRequiredMixin,DeleteView):
    model = City

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('common:city')


class ReligionListView(LoginRequiredMixin,ListView):

    model = Religion
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_religion_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('religion', )
        except KeyError:
            a = None
        if a:
            religion_list = Religion.objects.filter(
                name__icontains=a,
            )
        else:
            religion_list = Religion.objects.filter()
        return religion_list

    def dispatch(self, *args, **kwargs):
        return super(ReligionListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(ReligionListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Religion'
        return context


class ReligionCreate(LoginRequiredMixin,CreateView):
    form_class = ReligionForm
    model = Religion
    success_url = reverse_lazy('common:religion')

    def get_context_data(self, **kwargs):
        context = super(ReligionCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add Religion'
        return context

class ReligionUpdate(LoginRequiredMixin,UpdateView):
    form_class = ReligionForm
    model = Religion
    success_url = reverse_lazy('common:religion')

    def get_context_data(self, **kwargs):
        context = super(ReligionUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update Religion'
        return context

class ReligionDelete(LoginRequiredMixin,DeleteView):
    model = Religion

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('common:religion')

class CategoryListView(LoginRequiredMixin,ListView):

    model = Category
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_category_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('category', )
        except KeyError:
            a = None
        if a:
            category_list = Category.objects.filter(
                name__icontains=a,
            )
        else:
            category_list = Category.objects.filter()
        return category_list

    def dispatch(self, *args, **kwargs):
        return super(CategoryListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(CategoryListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Category'
        return context


class CategoryCreate(LoginRequiredMixin,CreateView):
    form_class = CategoryForm
    model = Category
    success_url = reverse_lazy('common:category')

    def get_context_data(self, **kwargs):
        context = super(CategoryCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add Category'
        return context

class CategoryUpdate(LoginRequiredMixin,UpdateView):
    form_class = CategoryForm
    model = Category
    success_url = reverse_lazy('common:category')

    def get_context_data(self, **kwargs):
        context = super(CategoryUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update Category'
        return context

class CategoryDelete(LoginRequiredMixin,DeleteView):
    model = Category

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('common:category')

class BankListView(LoginRequiredMixin,ListView):

    model = Bank
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_bank_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('bank', )
        except KeyError:
            a = None
        if a:
            bank_list = Bank.objects.filter(
                name__icontains=a,
            )
        else:
            bank_list = Bank.objects.filter()
        return bank_list

    def get_context_data(self, **kwargs):
        ctx = super(BankListView, self).get_context_data(**kwargs)
        ctx['pagetitle'] = 'RadintHRMS | Bank'
        #ctx['description'] = 'My Description'
        return ctx

    def dispatch(self, *args, **kwargs):
        return super(BankListView, self).dispatch(*args, **kwargs)


class BankCreate(LoginRequiredMixin,CreateView):
    form_class = BankForm
    model = Bank
    success_url = reverse_lazy('common:bank')

    def get_context_data(self, **kwargs):
        context = super(BankCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add Bank'
        return context

class BankUpdate(LoginRequiredMixin,UpdateView):
    form_class = BankForm
    model = Bank
    success_url = reverse_lazy('common:bank')

    def get_context_data(self, **kwargs):
        context = super(BankUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update Bank'
        return context

class BankDelete(LoginRequiredMixin,DeleteView):
    model = Bank

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

    success_url = reverse_lazy('common:bank')

class DepartmentListView(LoginRequiredMixin, ListView):
    model = Department
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_department_list'
    def get_queryset(self):
        try:
            a = self.request.GET.get('department', )
        except KeyError:
            a = None
        if a:
            department_list = Department.objects.filter(
                name__icontains=a,
            )
        else:
            department_list = Department.objects.filter()
        return department_list
    def dispatch(self, *args, **kwargs):
        return super(DepartmentListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(DepartmentListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Department'
        return context

class DepartmentCreate(LoginRequiredMixin, CreateView):
    form_class = DepartmentForm
    model = Department
    success_url = reverse_lazy('common:department')

    def get_context_data(self, **kwargs):
        context = super(DepartmentCreate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Add Department'
        return context

class DepartmentUpdate(LoginRequiredMixin, UpdateView):
    form_class = DepartmentForm
    model = Department
    success_url = reverse_lazy('common:department')

    def get_context_data(self, **kwargs):
        context = super(DepartmentUpdate, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Update Department'
        return context

class DepartmentDelete(LoginRequiredMixin, DeleteView):
    model = Department
    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)
        success_url = reverse_lazy('common:department')

class DesignationListView(LoginRequiredMixin, ListView):
    model = Designation
    paginate_by = 10  # if pagination is desired
    context_object_name = 'my_designation_list'

    def get_queryset(self):
        try:
            a = self.request.GET.get('designation', )
        except KeyError:
            a = None
        if a:
            designation_list = Designation.objects.filter(
                name__icontains=a,
            )
        else:
            designation_list = Designation.objects.filter()
        return designation_list
    def dispatch(self, *args, **kwargs):
        return super(DesignationListView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(DesignationListView, self).get_context_data(**kwargs)
        context['pagetitle'] = 'RadiantHRMS | Designation'
        return context

class DesignationCreate(LoginRequiredMixin, CreateView):
        form_class = DesignationForm
        model = Designation
        success_url = reverse_lazy('common:designation')

        def get_context_data(self, **kwargs):
            context = super(DesignationCreate, self).get_context_data(**kwargs)
            context['pagetitle'] = 'RadiantHRMS | Add Designation'
            return context

class DesignationUpdate(LoginRequiredMixin, UpdateView):
        form_class = DesignationForm
        model = Designation
        success_url = reverse_lazy('common:designation')

        def get_context_data(self, **kwargs):
            context = super(DesignationUpdate, self).get_context_data(**kwargs)
            context['pagetitle'] = 'RadiantHRMS | Update Designation'
            return context

class DesignationDelete(LoginRequiredMixin, DeleteView):
        model = Designation
        def get(self, *args, **kwargs):
            return self.post(*args, **kwargs)
        success_url = reverse_lazy('common:designation')

def export_country(request):
    country_resource = CountryResource()
    dataset = country_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="country.csv"'
    return response

def export_state(request):
    state_resource = StateResource()
    dataset = state_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="state.csv"'
    return response

def export_city(request):
    city_resource = CityResource()
    dataset = city_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="city.csv"'
    return response

def export_religion(request):
    religion_resource = ReligionResource()
    dataset = religion_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="religion.csv"'
    return response

def export_bank(request):
    bank_resource = BankResource()
    dataset = bank_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="bank.csv"'
    return response

def export_category(request):
    category_resource = CategoryResource()
    dataset = category_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="category.csv"'
    return response

def export_department(request):
    department_resource = DepartmentResource()
    dataset = department_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="department.csv"'
    return response

def export_designation(request):
    designation_resource = DesignationResource()
    dataset = designation_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="designation.csv"'
    return response