from import_export import resources
from .models import Country,State,City,Religion,Category,Bank,Department,Designation

class CountryResource(resources.ModelResource):
    class Meta:
        model = Country

class StateResource(resources.ModelResource):
    class Meta:
        model = State

class CityResource(resources.ModelResource):
    class Meta:
        model = City

class ReligionResource(resources.ModelResource):
    class Meta:
        model = Religion

class CategoryResource(resources.ModelResource):
    class Meta:
        model = Category

class BankResource(resources.ModelResource):
    class Meta:
        model = Bank

class DepartmentResource(resources.ModelResource):
    class Meta:
        model = Department

class DesignationResource(resources.ModelResource):
    class Meta:
        model = Designation
